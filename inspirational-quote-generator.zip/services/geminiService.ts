import { GoogleGenAI, Type } from "@google/genai";
import type { Quote } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const quoteSchema = {
  type: Type.OBJECT,
  properties: {
    quote: {
      type: Type.STRING,
      description: "The inspirational quote text.",
    },
    author: {
      type: Type.STRING,
      description: "The author of the quote. If unknown, use 'Anonymous'.",
    },
  },
  required: ["quote", "author"],
};

export async function generateQuote(topic: string): Promise<Quote> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Generate a short, powerful, and inspirational quote about ${topic}.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: quoteSchema,
      },
    });

    const jsonText = response.text.trim();
    const parsedJson = JSON.parse(jsonText);
    
    // Type check to ensure the response matches the Quote interface
    if (typeof parsedJson.quote === 'string' && typeof parsedJson.author === 'string') {
        return parsedJson as Quote;
    } else {
        throw new Error("Invalid response format from Gemini API");
    }

  } catch (error) {
    console.error("Error generating quote:", error);
    throw new Error("Failed to generate a quote. Please check your API key and try again.");
  }
}
