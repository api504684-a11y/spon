export interface Quote {
  quote: string;
  author: string;
}
