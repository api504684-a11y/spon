import React from 'react';

interface QuoteCardProps {
  quote: string;
  author: string;
}

const QuoteCard: React.FC<QuoteCardProps> = ({ quote, author }) => {
  return (
    <div className="bg-white/10 backdrop-blur-md rounded-xl shadow-2xl p-8 max-w-2xl w-full border border-white/20">
      <blockquote className="text-center">
        <p className="text-2xl md:text-4xl font-serif italic text-white leading-relaxed">
          “{quote}”
        </p>
        <cite className="block mt-6 text-lg text-gray-400 font-sans not-italic">
          — {author}
        </cite>
      </blockquote>
    </div>
  );
};

export default QuoteCard;
